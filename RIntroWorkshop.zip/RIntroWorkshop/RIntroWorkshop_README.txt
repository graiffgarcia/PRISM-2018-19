RIntroWorkshop_README.txt

Greetings! 

This folder contains the materials necessary for the 2018 PRISM Intro/Refresher for R Workshop conducted by Ricardo Graiff Garcia and Benjamin Campbell.  The working directories specified assume that this folder is located on your desktop.  There are four files, only one you will directly interact with:

-PRISM_RWorkshop_08202018.R: This is the script for the workshop.  The only thing that may need manipulated is working directories for these import files.
-values.csv: Imoprted data file
-Latin America legislator data.tab: Imported data file
-LeedsJohnsonJOPrep.dta: Imported data file

Please contact either Ricardo or Ben if you have questions.